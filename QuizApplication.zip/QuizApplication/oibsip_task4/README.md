# oibsip_task4
 In this app, questions would be asked and answers would be shown as multiple choices. The user selects the answer and gets shown on the screen if answer is correcr. In the end the final marks would be shown to the user.
