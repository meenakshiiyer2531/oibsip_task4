package com.example.quizapplication;

import static android.security.KeyChain.EXTRA_NAME;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Quiz extends AppCompatActivity implements View.OnClickListener{
    public TextView question, correct, result;
    public Button next;
    public RadioGroup sets;
    public RadioButton ans1, ans2, ans3, ans;
    String m, n;

    public int i = 0;
    public String ques[] = {"1. What is the pH value of the human body?", "2. Which of the " +
            "following are" +
            " called \"Key" +
            " Industrial animals\"?", "3. Which of the given amendments made it compulsory for " +
            "the " +
            " president to consent to the constitutional Amendment bills?", "4. Elections to " +
            "panchayats " +
            "in state are regulated by"};
    public String an1[] = {"9.2 to 9.8", "Producers", "27th", "Gram panchayat"};
    public String an2[] = {"7.0 to 7.8", "Tertiary consumers", "29th", "Nagar Nigam"};
    public String an3[] = {"6.1 to 6.3", "Primary consumers", "24th", "State Election Commission"};
    int sol[] = {2, 2, 3, 3};
    int count = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        question = findViewById(R.id.questions);
        correct = findViewById(R.id.correct);
        result = findViewById(R.id.result);
        next = findViewById(R.id.next);
        ans1 = findViewById(R.id.option1);
        ans2 = findViewById(R.id.option2);
        ans3 = findViewById(R.id.option3);
        sets = findViewById(R.id.group);
        ans1.setOnClickListener(this);
        ans2.setOnClickListener(this);
        ans3.setOnClickListener(this);
        next.setOnClickListener(this);
        loadNewQues();


    }

    void loadNewQues() {


        question.setText(ques[i]);
        ans1.setText(an1[i]);
        ans2.setText(an2[i]);
        ans3.setText(an3[i]);
        sets.setEnabled(true);
    }



    public void showresult()
    {
        Intent intent = getIntent();
  String m1 = intent.getStringExtra("message_key");
question.setVisibility(View.GONE);sets.setVisibility(View.GONE);next.setVisibility(View.GONE);
result.setVisibility(View.VISIBLE);
        result.setText("CONGRATULATIONS \n"+m1+" !!!!!! \n \n\n YOU SCORED : "+count);
        Toast.makeText(this, "CONGRATULATIONS "+m1+"!!!!!!!", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onClick(View v) {
        int selectedOptionId = sets.getCheckedRadioButtonId();
        Button clickedbutton = (Button) v;
       RadioButton selectedOptionRadioButton = findViewById(selectedOptionId);
     int selectedOptionIndex = sets.indexOfChild(selectedOptionRadioButton);
     if(clickedbutton.getId() == R.id.next) {

         i++; next.setText("CHECK"); correct.setText("");
         if(i>=4){ showresult();}else {
         loadNewQues();}
     }
     else {
        if (selectedOptionIndex +1 == sol[i]) {

                    ++count;
                    correct.setText("CONGRATS!!! YOUR ANSWER IS CORRECT");
                    next.setText("NEXT");

                } else {

                    correct.setText("THE CORRECT ANSWER WAS " + sol[i]);
                    next.setText("NEXT");


                }
            }
    }



}